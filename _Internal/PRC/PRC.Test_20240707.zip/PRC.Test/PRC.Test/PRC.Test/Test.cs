﻿using Task = System.Threading.Tasks.Task;

namespace PRC.Test
{
    public partial class Program
    {
        static async Task Main(string[] args)
        {
            while (true)
            {

                Console.WriteLine("Starting...");

                Console.WriteLine("Testing raw GRPC implementation...");

                await Test_GRPC();

                Console.WriteLine("Succeeded...");

                Console.WriteLine("Press button to continue");

                //Console.ReadKey();

                Console.WriteLine("Testing custom wrapper...");

                await Test_Wrapper();

                Console.WriteLine("Succeeded...");

                Console.WriteLine("Press button to close");

                //Console.ReadKey();
            }
        }

    }
}